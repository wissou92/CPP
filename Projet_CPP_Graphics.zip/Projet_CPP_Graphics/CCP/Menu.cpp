#include "Menu.h"
Menu::Menu(QWidget *parent): QWidget(parent) {

    setWindowTitle("Projet CPP");
     this -> resize(700,700);
     cree_Btn_Menu();

}


void Menu::cree_Btn_Menu()
{
    Test = new QPushButton("Test",this);
    btns.push_back(Test);
    Connexion = new QPushButton ("Connexion",this);
    btns.push_back(Connexion);
    Inscription = new QPushButton ("Inscription",this);
    btns.push_back(Inscription);
    Historique = new QPushButton ("Historique",this);
    btns.push_back(Historique);
    for (auto it = btns.begin() ; it !=btns.end(); ++it)
    (*it) -> setStyleSheet(
                   "border-style: outset;"
                   "border-width: 2px;"
                   "border-radius: 10px;"
                   "border-color: steelblue;"
                    "color: steelblue;"
                   "font: bold 14px;"
                   "min-width: 10em;"
                   " padding: 6px;" );


   Test -> move (280,150);
   Connexion -> move (280,250);
   Inscription -> move (280,350);
   Historique -> move (280,450);

}
