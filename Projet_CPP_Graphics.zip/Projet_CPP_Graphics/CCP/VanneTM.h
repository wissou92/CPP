#ifndef VANNETM_H
#define VANNETM_H

#include <QPainter>
#include <QWidget>
#include <QRect>
#include <QString>
#include "Vanne.h"
#include "Tank.h"
#include "Moteur.h"

class VanneTM : public Vanne , public QWidget{


private:

     Tank *t;
     Moteur * m;
     bool ouverte = false;

public:
    VanneTM(QString nom ,int type,QWidget *parent ,Tank * T,Moteur* M);
     virtual ~VanneTM();
     void paintEvent(QPaintEvent* e);
     Tank * get_Tank();
     Moteur * get_Moteur();
     bool get_etat();
     void open_close();

};
#endif // VANNETM_H
