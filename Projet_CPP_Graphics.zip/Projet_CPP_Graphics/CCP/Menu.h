#ifndef MENU_H
#define MENU_H
#include <QStackedWidget>
#include <QMainWindow>
#include <QApplication>
#include <QMenu>
#include <QMenuBar>
#include <QPushButton>
#include <QList>
#include <QPalette>
#include <QGridLayout>
class Menu : public QWidget {

  private:

    QWidget * m_myWidget ;

  public:
    QPushButton  *Test , *Connexion ,*Inscription ,*Historique;
    QList <QPushButton*> btns;
   Menu(QWidget *parent = 0);
   void cree_Btn_Menu();
   void cree_baground();

};
#endif // MENU_H
