#include "VanneTT.h"

VanneTT :: VanneTT( QString nom ,int type , QWidget *parent,Tank *T1 ,Tank *T2)
   :Vanne(nom,type),QWidget(parent)
{
   this ->setStyleSheet("QWidget{background-color: transparent;}");
   t1 = T1 ;
   t2 = T2 ;
   this -> resize(50,50);
}

VanneTT :: ~VanneTT(){}

void VanneTT :: paintEvent(QPaintEvent*e)
{
    Q_UNUSED(e);
    QPainter painter(this);
    painter.setBrush(Qt::black);
    painter.drawEllipse(QRect(0,0, 35, 35));
  if (ouverte){
             painter.setBrush(Qt::white);
             painter.drawRect(2,13, 31, 10);
         }
   else
        {
             painter.setBrush(Qt::white);
             painter.drawRect(13, 2, 10, 31);
         }
}


Tank*  VanneTT::get_Tank_1(){  return t1; }


Tank*  VanneTT::get_Tank_2(){  return t2; }

void  VanneTT::open_close()
{
    if (ouverte) ouverte = false ;
    else  ouverte = true;
}

bool VanneTT:: get_etat(){return ouverte; }





