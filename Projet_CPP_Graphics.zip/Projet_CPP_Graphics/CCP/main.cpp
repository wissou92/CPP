#include "System.h"
#include"FenetreP.h"
#include <QApplication>
#include <QMenu>
#include <QMenuBar>
#include "FenetreP.h"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
     FenetreP * F = new FenetreP();
     F->show();

    return a.exec();
}
