#ifndef HISTORIQUE_H
#define HISTORIQUE_H
#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <fstream>
#include <ostream>
#include <string>
#include <QDebug>
#include <QString>
using namespace std;

class Historique : public QWidget{
     Q_OBJECT
    private :
     ifstream myfile;
     QLabel * label;

    public:
             Historique(QWidget *parent = nullptr);
             virtual ~Historique();
             QPushButton * menu;
             void affichage_historique();
};
#endif // HISTORIQUE_H
