#include "Utilisateur.h"


Note::Note () {
	value = 0;
	suiv = nullptr;
}

Note::Note(Note &n1) {
	value = n1.get_value();
	suiv = n1.get_next();
}

Note::Note (int note, Note * suivant) {
	value = note;
	suiv = suivant;
}

ListeNote::ListeNote() {
	Note * first = new Note ();
	head = first;
}

ListeNote(ListeNote &l1) {
	head = l1.get_first();	
}

ListeNote::~ListeNote() {}

void ListeNote::add(int newNote) {
	Note ajt (newNote, nullptr);
	Note * tmp = this->get_first();
	while (tmp->get_next() != nullptr) {
		tmp = tmp->get_next();
	}
	tmp->get_next()->chg_suiv(&ajt);
	
}

Utilisateur::Utilisateur (string nnom, string nprenom) : notes() {
	nom = nnom;
	prenom = nprenom;
}


bool write_user(Utilisateur user) {
	ofstream flux;
	
	flux.open(NomFichier.c_str(), ios::app);
	if(!flux) {
		cout<<"Erreur : Impossible d'ouvrir le fichier"<<endl;
		return false;
	}
	else {
		Note note = user.get_notes().get_first();
		note = note.get_next();
		flux << user.get_nom() << " " << user.get_prenom();
		while(note != nullptr) {
			flux << " " << note.get_value;
		}
		flux << endl;
		return true;
	}	
	
	flux.close();
}

bool user_exists(Utilisateur user) {
	ifstream flux;
	flux.open(NomFichier.c_str());
	string mot;
	string ligne;
	do {
		flux >> mot;
		if( mot ==  ) {
			
	}
	while(!mot.empty());
	
	
	flux.close();
}
