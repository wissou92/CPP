#ifndef H_UTILISATEUR_H
#define H_UTILISATEUR_H




#include <iostream>
#include <string>
#include <cstring>


string const NomFichier("Save/notes.historique");

using namespace std;




class Note {
	
	private:
		int value;
		Note * suiv;
	
	public:
		Note();
		Note(Note &);
		Note(int, Note *);
		~Note();
		int get_value() {return value;}
		Note * get_next() {return suiv;}
		void chg_suiv(Note * next) {suiv = next;}
	
};

class ListeNote {
	
	private:
		Note * head;
		
	public:
		ListeNote();
		ListeNote(ListeNote &);
		~ListeNote();
		Note * get_first() {return head;}
		void add(int);
	
};

class Utilisateur {
	
	private:
		string nom;
		string prenom;	
		ListeNote notes;
		
	public:
		Utilisateur(string, string);
		~Utilisateur();
		string get_nom() { return nom;}
		string get_prenom() { return prenom;}
		ListeNote get_notes() { return notes;}	
};

bool write_user(Utilisateur user);

bool user_exists(Utilisateur user);



#endif
