Pour compiler l'application taper les commandes suivantes : 

make

et Lancer l'executable "app" dans le dossier "App"
