#ifndef VANNETT_H
#define VANNETT_H
#include <QPainter>
#include <QWidget>
#include <QRect>
#include <QString>
#include "Vanne.h"
#include "Tank.h"

class VanneTT : public Vanne , public QWidget{


private:

     Tank *t1 , *t2;
     bool ouverte = false ;
public:
  VanneTT( QString nom ,int t ,QWidget *parent ,Tank* , Tank *);

     virtual ~VanneTT();
     void paintEvent(QPaintEvent* e);
     Tank * get_Tank_1();
     Tank * get_Tank_2();
     bool get_etat();
     void open_close();

};
#endif // VANNETT_H
