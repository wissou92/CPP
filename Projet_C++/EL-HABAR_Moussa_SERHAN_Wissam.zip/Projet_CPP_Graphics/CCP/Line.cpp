#include "Line.h"

Line::Line(int x,int y,int x1 ,int y1 ,QWidget *parent ):QWidget(parent)
{

     this -> setStyleSheet("background-color: white;");
      px1 = x;
      py1 = y;
      px2 = x1;
      py2 = y1;
      this -> resize(700,700);
}

void Line :: paintEvent(QPaintEvent*e)
{
    Q_UNUSED(e);
    QLineF line(px1,py1, px2,py2);
    QPainter painter(this);
    painter.drawLine(line);
    painter.setPen(Qt:: black);
    painter.setBrush(Qt::black);
}


Line::~Line(){}
