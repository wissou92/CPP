#ifndef THREADD_H
#define THREADD_H
#include <QObject>
#include <QThread>
#include <QProgressDialog>
#include <QThread>
class Process : public QThread {
    Q_OBJECT
private:
    bool m_stop;
public:
    Process () {};
    ~Process () {};
    // Méthode du processus...
    void run () {
        m_stop = false;
        int val =300;
       while( val != 0 )
       {
            val -= 5 ;
            emit progressValue (val);
            sleep (1);
        }
    };
signals:
    void progressValue (const int);
public slots:
    void cancel () {
        m_stop = true;
    };
};
#endif // THREADD_H
