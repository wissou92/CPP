#include "FenetreP.h"

FenetreP ::FenetreP(QWidget * parent) : QMainWindow(parent)
{
    setWindowTitle("Projet CPP"); resize(700,700);

    stack = new QStackedWidget(this);
    stack -> resize(700,700);
    c=  new Connexion(this);
    s = new System(this);
    menu = new Menu(this);
    hist = new Historique(this);

    stack->addWidget(menu);//0
    stack->addWidget(s);//1
    stack->addWidget(c);//2
    stack->addWidget(hist);//3

    //stack->addWidget(fen3);
    //stack->addWidget(fen4);
    stack->setCurrentIndex(0);

    for (auto it = menu ->btns.begin(); it != menu ->btns.end(); ++it ){
       connect(*it, SIGNAL(clicked()),SLOT(changement_Fenetre()));
    }
     connect(s->Menu, SIGNAL(clicked()),SLOT(changement_Fenetre()));
     connect(hist->menu, SIGNAL(clicked()),SLOT(changement_Fenetre()));
     connect(c->btn, SIGNAL(clicked()),SLOT(changement_Fenetre()));
     connect(c ,SIGNAL(est_connecte()),SLOT(changement_Fenetre()));

   update();
}




void FenetreP::changement_Fenetre()
{

   if( s ->Menu ==(QPushButton*)sender()){
                sauvegarder_la_note();
                stack-> removeWidget(s);
                delete s ;
                s= new System(this);
                s->update();
                stack ->insertWidget(1, s);
                stack -> update();
                stack->setCurrentIndex(0);
                this -> update();
    }

    if( menu ->Test ==(QPushButton*)sender())
    {
        stack->setCurrentIndex(1);
    }
       if(c->btn  ==(QPushButton*)sender()){  stack->setCurrentIndex(0);}

       if(menu ->Connexion ==(QPushButton*)sender()){stack->setCurrentIndex(2);}
       if(c ==(Connexion*)sender()){stack->setCurrentIndex(1);}
       if(menu ->Historique ==(QPushButton*)sender()){stack->setCurrentIndex(3);}
       if(hist ->menu ==(QPushButton*)sender()){stack->setCurrentIndex(0);}
        stack -> update();

}


void FenetreP::sauvegarder_la_note()
{
    myfile.open ("fic.txt",std::ios::app);

  if (c -> user){
    if(myfile) {
                int note = s->note -15 ;
                if(note < 0) {
					note = -note%11;
				}
				else if (note == 0) { note = 1;}
                myfile<<c ->unom.toStdString() <<" "<<
                c ->uprenom.toStdString()<<" " << note<< endl;
               }
    else{
            std::cout<< "ERREUR: Impossible d'ouvrir le fichier." << std::endl;
        }
  }
    myfile.close();
}
