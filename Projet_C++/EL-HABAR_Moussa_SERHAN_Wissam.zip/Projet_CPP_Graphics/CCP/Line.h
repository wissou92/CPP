#ifndef LINE_H
#define LINE_H
#include <QWidget>
#include <QPainter>
#include<QLineF>

class Line:public QWidget{
    Q_OBJECT
public :
     int px1, py1 , px2, py2;
     Line(int x  , int y, int x1 , int y1 , QWidget *parent = nullptr);
     virtual ~Line();
     void paintEvent(QPaintEvent* e);
};

#endif // LINE_H
