#include "VanneTM.h"

VanneTM::VanneTM(QString nom,int type , QWidget *parent,Tank *T ,Moteur *M)
        :Vanne(nom,type),QWidget(parent)
{
    this ->setStyleSheet("QWidget{background-color: transparent;}");

   t = T;
   m = M ;
   this -> resize(50,50);
}

VanneTM :: ~VanneTM(){}

void VanneTM :: paintEvent(QPaintEvent*e)
{
    Q_UNUSED(e);
    QPainter painter(this);
    painter.setBrush(Qt::black);
    painter.drawEllipse(QRect(0,0, 35, 35));
   if (ouverte){
             painter.setBrush(Qt::white);
             painter.drawRect(2,13, 31, 10);}
    else{
             painter.setBrush(Qt::white);
             painter.drawRect(13, 2, 10, 31);}
}

Tank*VanneTM::get_Tank(){ return  t; }

Moteur*VanneTM::get_Moteur(){ return  m; }

void  VanneTM::open_close(){
    if (ouverte) ouverte = false ;
    else ouverte = true;
}

bool VanneTM:: get_etat(){return ouverte; }
