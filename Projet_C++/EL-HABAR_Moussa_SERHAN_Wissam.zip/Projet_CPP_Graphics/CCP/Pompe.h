#ifndef POMPE_H
#define POMPE_H
#include <QWidget>
#include <QString>
#include <QPainter>

enum Etat { ON, OFF};

class Pompe : public  QWidget{
     Q_OBJECT
    private:

        Etat etat = OFF;
        bool panne = false;
        QString name ;
    public :

        Pompe(QString  nom , QWidget * parent =0);

        void paintEvent(QPaintEvent* e);
        virtual ~Pompe();
        Etat get_etat();
        void start_stop();
        void generer_Panne_Pompe();
        bool get_etat_panne();

};
#endif // POMPE_H
