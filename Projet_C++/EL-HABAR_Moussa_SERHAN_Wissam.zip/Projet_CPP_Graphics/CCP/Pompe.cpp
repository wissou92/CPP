#include "Pompe.h"
#include <QDebug>

Pompe::Pompe(QString nom ,QWidget *parent):QWidget(parent)
{
     this ->setStyleSheet("QWidget{background-color: transparent;}");
        name =nom;
        this->resize(50,50);
}

Pompe::~Pompe(){}

void Pompe:: paintEvent(QPaintEvent* e)
{
      update();
    Q_UNUSED(e);
   if (etat == ON){
               QPainter painter(this);
               painter.setBrush(Qt::green);
               painter.drawEllipse(QRect(0,0, 22, 22));
               painter.setPen(Qt:: white);
               painter.drawText(6,15, name);}
    else{
               QPainter painter(this);
               painter.setBrush(Qt::red);
               painter.drawEllipse(QRect(0,0, 22, 22));
               painter.setPen(Qt:: white);
               painter.drawText(6,15, name);
       }

}

void Pompe::start_stop()
{
    if  (!panne && etat == OFF) { etat = ON;}
    else if (!panne && etat == ON) {etat = OFF;}
    else { etat = OFF ;}
}

Etat Pompe::get_etat()
{
    return etat ;
}

void Pompe::generer_Panne_Pompe()
{
    panne = true;
    update();
}

bool Pompe::get_etat_panne()
{
    return panne;
}
