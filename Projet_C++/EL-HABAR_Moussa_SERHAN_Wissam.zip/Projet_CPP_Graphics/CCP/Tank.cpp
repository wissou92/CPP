#include "Tank.h"

Tank :: Tank(QWidget * parent ,int cap):QWidget(parent)
{
       this ->setStyleSheet("QWidget{background-color: transparent;}");
       primaire   = new Pompe("P1",this) ;
       primaire -> start_stop();
       secondaire = new Pompe("P2",this) ;
       capacity =cap ;
       progressBar = new QProgressBar(this);
       progressBar ->setOrientation(Qt::Vertical);
       progressBar->setMinimum(0);
       progressBar->setMaximum(capacity);

        this->resize(150,100);
        if (capacity == 500){
           progressBar->resize(80,100) ;
           progressBar -> setValue(capacity);
           progressBar -> setRange(0,capacity);
           progressBar -> move(25,0);
           secondaire -> move(0,25);
        }
        else{
            progressBar->resize(60,80) ;
            progressBar -> setValue(capacity);
            progressBar -> setRange(0,capacity);
            progressBar -> move(25,0);
            secondaire  -> move(0,25);
        }


 }


void Tank::mise_a_jour()
{
    int val = progressBar -> value() - 10;
    progressBar->setValue(val);
}

bool Tank:: get_Panne()
{
    return panne ;
}

Pompe * Tank :: get_Primaire()
{
    return primaire;
}

Pompe * Tank ::get_Secondaire()
{
    return secondaire;
}

int Tank:: get_Carburant()
{
    return progressBar -> value();
}

void Tank::Panne_Reservoir()
{
    panne = true ;
}

bool Tank::get_etat(){
if((primaire->get_etat()==ON||secondaire->get_etat()== ON)
     && !panne)
    {return true;}
else
    {return false;}
}

void Tank::activer_Secondaire()
{
    secondaire -> start_stop();
}
void Tank :: augmenter_Value()
{
    int val = progressBar -> value() + 10;
    progressBar->setValue(val);
}

