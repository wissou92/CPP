#include "Vanne.h"

Vanne::Vanne(QString nom ,int t)
{

 name =nom;
 type = t;
}

Vanne :: ~Vanne(){}

QString Vanne :: get_Name()
{
    return name;
}

int Vanne ::get_Type()
{
    return type;
}




