#include "Historique.h"

Historique::Historique(QWidget * parent):QWidget(parent)
{
  this -> resize(700,700);
  menu = new QPushButton("Menu",this);
  menu -> setStyleSheet(
              "border-style: outset;"
              "border-width: 2px;"
              "border-radius: 10px;"
              "border-color: steelblue;"
               "color: steelblue;"
              "font: bold 10px;"
              "min-width: 5em;"
              " padding: 3px;" );
  affichage_historique();
}
Historique::~Historique(){}

void Historique::affichage_historique()
{
  myfile.open ("fic.txt");
    if(myfile) {
	  int i = -300;
      string ligne;
      while( getline(myfile, ligne))
      {
          qDebug()<< QString::fromStdString(ligne) <<endl ;
          label = new QLabel(QString::fromStdString(ligne),this);
          label -> resize(250, 700);
          label -> move  (300,i);
                  i+=50;

      }
 }
    else{
            //cout<< "ERREUR: Impossible d'ouvrir le fichier." <<endl;

  }
    myfile.close();
}

