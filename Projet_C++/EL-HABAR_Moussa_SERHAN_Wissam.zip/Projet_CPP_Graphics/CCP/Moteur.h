#ifndef MOTEUR_H
#define MOTEUR_H
#include <QWidget>
#include <QPainter>
#include <QString>
#include "Tank.h"
#include <QDebug>


class Moteur : public QWidget{
     Q_OBJECT
    private :
    QString name;
    bool alimentee;
    Tank * tank_alim ;

    public:
             Moteur(QString ,Tank *, QWidget *parent = nullptr);
             virtual ~Moteur();
             void paintEvent(QPaintEvent* e);
             void changer_Couleur();
             void changer_Reservoir(Tank *);
             bool est_Alimentee();
             Tank * get_Tank();
             QString get_Name();

     signals:
            void non_alimenter();
};
#endif
