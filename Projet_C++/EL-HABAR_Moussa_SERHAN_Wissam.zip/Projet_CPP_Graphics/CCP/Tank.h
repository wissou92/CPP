#ifndef TANK_H
#define TANK_H
#include <QWidget>
#include <QProgressBar>
#include <QDebug>
#include  "Pompe.h"

class Tank : public QWidget{
    Q_OBJECT

private:
    int capacity ;
    bool panne = false;

public:

    Pompe *primaire , *secondaire;
    QProgressBar *progressBar;
    Tank(QWidget * parent , int cap );
    int get_Carburant();
    Pompe * get_Primaire();
    Pompe * get_Secondaire();
    bool get_Panne();
    void Panne_Primaire();
    void Panne_Secondaire();
    void Panne_Reservoir();
    void activer_Secondaire();
    bool get_etat();


signals:
     void est_vide();

public slots:
    void mise_a_jour();
    void augmenter_Value();


};
#endif // TANK_H
