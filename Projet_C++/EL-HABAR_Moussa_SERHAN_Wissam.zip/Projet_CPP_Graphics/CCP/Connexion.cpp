#include "Connexion.h"

Connexion::Connexion(QWidget *parent):QWidget(parent)
{
   resize(700,700);
   setWindowTitle("Projet CPP");
   Decoration();
   QObject::connect(se_Connecter, SIGNAL(clicked()) ,SLOT(stocker_nom_prenom()));
}


void Connexion::Decoration(){
    QLabel *label = new QLabel(this);
    label->setText("votre nom :");
    label-> setStyleSheet(
                          "color:steelblue;"
                          "font: bold 14px;"
                          "min-width: 8em;"
                          "padding: 6px;" );
    label-> move(190,235);
    label -> resize (100,100);


    QLabel *label1 = new QLabel(this);
    label1->setText("votre prénom :");
    label1-> setStyleSheet(
                          "color:steelblue;"
                          "font: bold 14px;"
                          "min-width: 8em;"
                          "padding: 6px;" );
    label1-> move(190,335);
    label1 -> resize (100,100);


    se_Connecter = new QPushButton("Se connecter",this);
    se_Connecter -> setStyleSheet(
                       "border-style: outset;"
                       "border-width: 2px;"
                       "border-radius: 8px;"
                       "border-color: steelblue;"
                       "color:steelblue;"
                       "font: bold 14px;"
                       "min-width: 8em;"
                       "padding: 6px;" );

    nom = new QLineEdit(this);
    nom-> setStyleSheet(
                "border-style: outset;"
                "border-width: 2px;"
                "border-radius: 8px;"
                "border-color: steelblue;"
                "color:steelblue;"
                "font: bold 14px;"
                "min-width: 8em;"
                "padding: 6px;" );

    prenom = new QLineEdit(this);
    se_Connecter -> move (275,550);
    nom ->  move (200,300);
    nom -> resize (300,30);
    prenom ->  move (200,400);
    prenom -> resize (300,30);
    prenom -> setStyleSheet(
                "border-style: outset;"
                "border-width: 2px;"
                "border-radius: 8px;"
                "border-color: steelblue;"
                "color:steelblue;"
                "font: bold 14px;"
                "min-width: 8em;"
                "padding: 6px;" );


     btn =new QPushButton("Retour",this);
     btn -> setStyleSheet(
                 "border-style: outset;"
                 "border-width: 2px;"
                 "border-radius: 8px;"
                 "border-color: steelblue;"
                 "color:steelblue;"
                 "font: bold 10px;"
                 "min-width: 8em;"
                 "padding: 6px;" );


}


void Connexion:: stocker_nom_prenom()
{
    if (!nom -> text().isEmpty() && !prenom-> text().isEmpty() )
     {
      unom =  nom -> text();
      uprenom= prenom -> text();
      user=true;
      emit est_connecte();

     }
    qDebug()<< unom  << "     " <<  uprenom << endl ;
}
