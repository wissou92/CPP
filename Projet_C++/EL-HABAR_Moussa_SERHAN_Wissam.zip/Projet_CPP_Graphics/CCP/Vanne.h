#ifndef GVANNE_H
#define GVANNE_H
#include <QString>

// cette classe elle herite pas de qwidget
//par ce que je vais men servir pour savoir
// le type de la  vanne
// par contre les fille
//VanneTT et VanneTM
// oui par ce que cest des widgets




class Vanne{

protected:
     QString name;
     // TT : type 1   TM: type2
     //en vrai osef vu qon a deux class mais bn
     int type;

public:
     Vanne(QString nom  ,int t);
     ~Vanne();
     QString get_Name();
     int get_Type();



};
#endif // GVANNE_H
