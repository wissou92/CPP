#include "Moteur.h"

Moteur::Moteur(QString nom ,Tank * T,QWidget *parent):QWidget(parent)
{
   this ->setStyleSheet("QWidget{background-color: transparent;}");
        name =nom;
        tank_alim = T ;
        this->resize(100, 100);

        if (tank_alim->get_etat()  &&tank_alim ->progressBar->value() >0 )
          alimentee = true;
        else alimentee = false ;

}

Moteur :: ~Moteur(){}

void Moteur :: paintEvent(QPaintEvent*e){
    Q_UNUSED(e);
    QPainter painter(this);

    if (alimentee)
    {
                painter.setBrush(Qt::red);
                painter.drawRect(0, 0, 99, 99);
                painter.setPen(Qt:: white);
                painter.drawText(45,48, name);
    }
    else
    {
                painter.setBrush(Qt::gray);
                painter.drawRect(0, 0, 99, 99);
                painter.setPen(Qt:: red);
                painter.drawText(45,48, name);
    }

   if ( !tank_alim->get_etat()   || tank_alim -> progressBar -> value() == 0 )
       emit non_alimenter();
   else  alimentee= true;

    update();
}

void  Moteur:: changer_Couleur()
{
  if (tank_alim->get_etat()  &&  tank_alim ->progressBar->value() > 0  )
      alimentee= true;
   else alimentee = false;


}

void Moteur :: changer_Reservoir(Tank * nouveau)
{
    tank_alim = nouveau ;
    if (tank_alim->get_etat() && tank_alim ->progressBar->value() > 0)
       alimentee= true;
     else alimentee = false;
    update();
}


bool Moteur:: est_Alimentee()
{
     return alimentee ;
}

QString Moteur::get_Name()
{
    return name;
}

Tank * Moteur ::get_Tank()
{
    return tank_alim;
}


